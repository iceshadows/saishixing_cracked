// ==UserScript==
// @name         近代史纲要作弊脚本
// @namespace    http://tampermonkey.net/
// @version      0.4
// @description  作弊计划
// @author       QDUWO™开发团队
// @match        saishi.cnki.net/**
// @grant        none
// ==/UserScript==

(function () {
  'use strict';
  $('head').append('<meta http-equiv="Access-Control-Allow-Origin" content="*">');
  // 增加中文URL
  var tamp = document.getElementsByClassName('tigan')[0];
  tamp.id = "qduwo";
  // 把对应节点放在第一个Header类之后，为了避免出现冲突，增加id标签
  var tmp = document.getElementsByClassName('tixing')[0];
  tmp.id = "Aimloc";
  // $("#Aimloc").after('<meta http-equiv="Access-Control-Allow-Origin" content="*">');
  $('#qduwo').after('<input type="text" id="website" value="http://www.sitepoint.com/" /><button id="JCJ1Button" data-copytarget="#website" click = "copy()">copy</button>');

  var EleP = document.getElementById('website');
  EleP.size = 80;
  EleP.value = tamp.innerHTML;

  // copy其他人的代码：使用javascript进行复制到剪切板的操作
  document.body.addEventListener('click', copy, true);
  // event handler
  function copy(e) {
    // 增加中文URL
    var tamp = document.getElementsByClassName('tigan')[0];
    tamp.id = "qduwo";
    var EleP = document.getElementById('website');
    EleP.size = 80;
    EleP.value = tamp.innerHTML;
    let question = tamp.innerHTML;
    question = question.replace(/\s+/g,"");
    console.log("查询的题干" + question);
    console.log("提交");
    var answer = $.ajax({
      type: 'GET',
      crossDomain: true,
      url: 'https://api.qduwo.xyz/getjindai',
      data: { question: question },
      dataType: "json",
      xhrFields: {
        'Access-Control-Allow-Origin': '*'
      },
      success: function (res) {
        console.log(res);
        let answers = res.answer
        for(let i = 0;i<answers.length;i++){
          document.getElementById('website').after("<p>"+answers[i]+"</p>");
        }
      },
      fail:function(){
        console.log("失败");
      }
    });

    EleP.size = 80;
    EleP.value = answer.responseText;
    // find target element
    var
      t = e.target,
      c = t.dataset.copytarget,
      inp = (c ? document.querySelector(c) : null);

    // is element selectable?
    if (inp && inp.select) {

      // select text
      inp.select();

      try {
        // copy text
        document.execCommand('copy');
        inp.blur();

        // copied animation
        t.classList.add('copied');
        setTimeout(function () { t.classList.remove('copied'); }, 1500);
      }
      catch (err) {
        alert('please press Ctrl/Cmd+C to copy');
      }

    }

  }

})();